package in.xvidia.cloud.discoveryapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoDiscoveryAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoDiscoveryAppApplication.class, args);
    }
}
