package in.xvidia.cloud.clientapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoClientAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoClientAppApplication.class, args);
    }
}
