package eurekaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicediscApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServicediscApplication.class, args);
    }
}
